#!/usr/bin/env python3
"""
Password Vault – A Simple Local Password Manager (CLI)
Author: EldoHub Weekend Assignment
Python >= 3.9

Usage examples:
  Initialize a new vault (creates salt and empty vault file):
    python vault.py init --vault myvault.json

  Add a new entry (you'll be prompted for the master password and the account password):
    python vault.py add --vault myvault.json --name "github" --username "alice"

  Retrieve passwords by keyword (in name or username; prints masked by default):
    python vault.py get --vault myvault.json --keyword "git" --reveal

  Delete an entry by exact name:
    python vault.py delete --vault myvault.json --name "github"

  List entries (without showing passwords):
    python vault.py list --vault myvault.json

Security note:
- Passwords are encrypted at rest using Fernet, with a key derived from your master password via PBKDF2-HMAC-SHA256.
- The randomly generated salt is stored in a sibling file <vault>.salt. Keep both files safe.
- Anyone with BOTH the vault file, the salt, and your master password can decrypt your passwords.
"""
from __future__ import annotations
import argparse
import getpass
import json
import os
import sys
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
from base64 import urlsafe_b64encode
from cryptography.fernet import Fernet, InvalidToken
from hashlib import sha256
from pathlib import Path
from secrets import token_bytes
from datetime import datetime

try:
    # Python 3.10+:
    from hashlib import pbkdf2_hmac
except ImportError:
    from hashlib import pbkdf2_hmac  # type: ignore


VAULT_VERSION = 1
DEFAULT_VAULT = "vault.json"
ITERATIONS = 390000  # PBKDF2 iterations (reasonable default for local tool)


def _salt_path(vault_path: Path) -> Path:
    return vault_path.with_suffix(vault_path.suffix + ".salt")


def derive_key(master_password: str, salt: bytes) -> bytes:
    """Derive a 32-byte key from a master password and salt using PBKDF2-HMAC-SHA256, then url-safe base64-encode for Fernet."""
    if not master_password:
        raise ValueError("Master password cannot be empty.")
    dk = pbkdf2_hmac("sha256", master_password.encode("utf-8"), salt, ITERATIONS, dklen=32)
    return urlsafe_b64encode(dk)


def load_or_create_salt(vault_path: Path) -> bytes:
    spath = _salt_path(vault_path)
    if spath.exists():
        return spath.read_bytes()
    salt = token_bytes(16)
    spath.write_bytes(salt)
    return salt


@dataclass
class Entry:
    name: str
    username: str
    password_encrypted: str
    created_at: str

    @staticmethod
    def from_plain(name: str, username: str, password_plain: str, fernet: Fernet) -> "Entry":
        token = fernet.encrypt(password_plain.encode("utf-8"))
        return Entry(
            name=name.strip(),
            username=username.strip(),
            password_encrypted=token.decode("utf-8"),
            created_at=datetime.utcnow().isoformat() + "Z",
        )

    def decrypt_password(self, fernet: Fernet) -> str:
        return fernet.decrypt(self.password_encrypted.encode("utf-8")).decode("utf-8")


class Vault:
    def __init__(self, path: Path):
        self.path = path
        self.entries: Dict[str, Entry] = {}
        self.version = VAULT_VERSION

    def load(self) -> None:
        if not self.path.exists():
            # Start with empty vault if file missing; creation happens on save
            self.entries = {}
            self.version = VAULT_VERSION
            return
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("version") != VAULT_VERSION:
            raise ValueError(f"Unsupported vault version: {data.get('version')}")
        items = data.get("entries", [])
        self.entries = {it["name"]: Entry(**it) for it in items}

    def save(self) -> None:
        data = {
            "version": self.version,
            "entries": [asdict(e) for e in sorted(self.entries.values(), key=lambda x: x.name.lower())],
        }
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def add(self, entry: Entry) -> None:
        if entry.name in self.entries:
            raise ValueError(f"Entry with name '{entry.name}' already exists.")
        self.entries[entry.name] = entry
        self.save()

    def delete(self, name: str) -> bool:
        if name in self.entries:
            del self.entries[name]
            self.save()
            return True
        return False

    def search(self, keyword: str) -> List[Entry]:
        kw = keyword.lower()
        return [e for e in self.entries.values() if kw in e.name.lower() or kw in e.username.lower()]

    def list_names(self) -> List[str]:
        return sorted(self.entries.keys(), key=str.lower)


def prompt_master_password(confirm: bool = False) -> str:
    pw = getpass.getpass("Master password: ")
    if not pw:
        raise SystemExit("Master password cannot be empty.")
    if confirm:
        pw2 = getpass.getpass("Confirm master password: ")
        if pw != pw2:
            raise SystemExit("Master password mismatch.")
    return pw


def prompt_account_password() -> str:
    pw = getpass.getpass("Account password to store: ")
    if not pw:
        raise SystemExit("Account password cannot be empty.")
    return pw


def get_fernet(vault_path: Path, master_password: str, create_salt_if_missing: bool = True) -> Fernet:
    salt = load_or_create_salt(vault_path) if create_salt_if_missing else _salt_path(vault_path).read_bytes()
    key = derive_key(master_password, salt)
    return Fernet(key)


def cmd_init(args: argparse.Namespace) -> None:
    path = Path(args.vault or DEFAULT_VAULT)
    if path.exists():
        print(f"[!] Vault already exists at {path}. Nothing to do.")
        return
    # force salt creation
    _ = load_or_create_salt(path)
    v = Vault(path)
    v.save()
    print(f"[+] Initialized empty vault at {path} and created salt at {_salt_path(path)}")


def cmd_add(args: argparse.Namespace) -> None:
    path = Path(args.vault or DEFAULT_VAULT)
    master = prompt_master_password()
    f = get_fernet(path, master)
    v = Vault(path)
    v.load()

    name = args.name.strip()
    username = args.username.strip()
    if not name:
        raise SystemExit("Name cannot be empty.")
    if not username:
        raise SystemExit("Username cannot be empty.")
    password_plain = args.password or prompt_account_password()

    entry = Entry.from_plain(name, username, password_plain, f)
    v.add(entry)
    print(f"[+] Added entry '{name}' for user '{username}'.")


def cmd_get(args: argparse.Namespace) -> None:
    path = Path(args.vault or DEFAULT_VAULT)
    master = prompt_master_password()
    f = get_fernet(path, master, create_salt_if_missing=False)
    v = Vault(path)
    v.load()

    results = v.search(args.keyword.strip())
    if not results:
        print("No matching entries.")
        return

    for e in results:
        if args.reveal:
            try:
                pw = e.decrypt_password(f)
            except InvalidToken:
                print(f"[!] Could not decrypt password for '{e.name}'. Is the master password correct?")
                continue
            print(f"name={e.name}  username={e.username}  password={pw}")
        else:
            print(f"name={e.name}  username={e.username}  password=****** (use --reveal to show)")


def cmd_delete(args: argparse.Namespace) -> None:
    path = Path(args.vault or DEFAULT_VAULT)
    v = Vault(path)
    v.load()
    ok = v.delete(args.name.strip())
    if ok:
        print(f"[+] Deleted entry '{args.name}'.")
    else:
        print(f"[!] No entry named '{args.name}' was found.")


def cmd_list(args: argparse.Namespace) -> None:
    path = Path(args.vault or DEFAULT_VAULT)
    v = Vault(path)
    v.load()
    names = v.list_names()
    if not names:
        print("(empty)")
        return
    for n in names:
        print(n)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Password Vault – local CLI password manager")
    p.add_argument("--vault", default=DEFAULT_VAULT, help="Path to vault JSON file (default: vault.json)")

    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("init", help="Initialize a new vault")
    sp.set_defaults(func=cmd_init)

    sp = sub.add_parser("add", help="Add a new password entry")
    sp.add_argument("--name", required=True, help="Entry name (e.g., 'github')")
    sp.add_argument("--username", required=True, help="Account username/email")
    sp.add_argument("--password", help="Account password (omit to be prompted securely)")
    sp.set_defaults(func=cmd_add)

    sp = sub.add_parser("get", help="Retrieve password(s) by keyword")
    sp.add_argument("--keyword", required=True, help="Keyword in name or username")
    sp.add_argument("--reveal", action="store_true", help="Reveal decrypted password(s)")
    sp.set_defaults(func=cmd_get)

    sp = sub.add_parser("delete", help="Delete an entry by exact name")
    sp.add_argument("--name", required=True, help="Exact entry name to delete")
    sp.set_defaults(func=cmd_delete)

    sp = sub.add_parser("list", help="List entry names")
    sp.set_defaults(func=cmd_list)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    try:
        parser = build_parser()
        args = parser.parse_args(argv)
        args.func(args)
        return 0
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130
    except FileNotFoundError as e:
        print(f"File error: {e}", file=sys.stderr)
        return 2
    except InvalidToken:
        print("Decryption failed. Wrong master password?", file=sys.stderr)
        return 3
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
