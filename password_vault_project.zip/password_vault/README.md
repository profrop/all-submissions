# Password Vault – A Simple Local Password Manager (CLI)

A weekend assignment for EldoHub's Data Science Department. This tool stores/retrieves passwords locally with encryption.

## Features
- Add a new password entry (name, username, password)
- Retrieve password(s) using a keyword (mask or reveal)
- Delete password entry
- Encrypt/decrypt using **Fernet** (AES-128 + HMAC; key derived from master password via PBKDF2-HMAC-SHA256)
- Save/load the password vault as a **JSON** file
- Simple, dependency-light, tested with `pytest`

## Quick Start
```bash
# 1) Create and activate a virtual environment (recommended)
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

# 2) Install requirements
pip install -r requirements.txt

# 3) Initialize a new vault
python vault.py init --vault myvault.json

# 4) Add an entry
python vault.py add --vault myvault.json --name "github" --username "alice"
# You'll be prompted for:
#   - Master password (stored only in your head; used to derive encryption key)
#   - Account password (the password to store for this entry)

# 5) Retrieve by keyword (mask or reveal)
python vault.py get --vault myvault.json --keyword "git"           # masked
python vault.py get --vault myvault.json --keyword "git" --reveal  # shows decrypted password

# 6) Delete by name
python vault.py delete --vault myvault.json --name "github"

# 7) List entries
python vault.py list --vault myvault.json
```

### Files Created
- `myvault.json` – your encrypted entries (passwords encrypted per-entry using Fernet)
- `myvault.json.salt` – random salt used with PBKDF2 to derive a key from your master password

> ✅ Keep both files safe and back them up together. Without the **master password**, your data cannot be decrypted.

## Design
- **Encryption**: Fernet from `cryptography`. Master password → PBKDF2-HMAC-SHA256 → 32-byte key → Fernet key.
- **Storage**: JSON with `version`, `entries`. Each entry stores `name`, `username`, `password_encrypted`, `created_at`.
- **CLI**: `argparse` subcommands: `init`, `add`, `get`, `delete`, `list`.
- **Input validation**: empty names/usernames/passwords rejected.
- **Exceptions**: Friendly error messages for common issues (bad master password, duplicate names, missing files).

## Testing
Run tests with `pytest`:
```bash
pip install -r requirements-dev.txt
pytest -q
```

## Reproducibility
- Exact steps are in this README.
- Dependencies are pinned in `requirements.txt` / `requirements-dev.txt`.
- Use meaningful git commits (examples below).

## Example Git Commit Messages
- `feat(vault): add init/add/get/delete/list subcommands`
- `feat(crypto): derive key via PBKDF2 and encrypt with Fernet`
- `test(cli): add happy-path and duplicate-entry tests`
- `docs(readme): add quickstart and security notes`
- `chore: pin dependencies, add .gitignore`

## Security Notes
- Anyone with **vault file + salt file + master password** can decrypt. Protect your master password.
- If you forget your master password, **there is no recovery**.
- This is a learning project; for production use, consider additional hardening (key stretching parameters, lockouts, argon2, OS keyrings, etc.).

## License
MIT
