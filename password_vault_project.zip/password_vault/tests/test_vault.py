import os
import json
import tempfile
from pathlib import Path
from subprocess import run, PIPE
import sys

PY = sys.executable
CLI = str(Path(__file__).resolve().parents[1] / "vault.py")

def cli(*args, input_bytes: bytes | None = None):
    return run([PY, CLI, *args], input=input_bytes, stdout=PIPE, stderr=PIPE)

def test_init_and_add_and_get_and_delete(tmp_path: Path, monkeypatch):
    vault = tmp_path / "tvault.json"

    # init
    r = cli("--vault", str(vault), "init")
    assert r.returncode == 0
    assert vault.exists()
    assert (Path(str(vault) + ".salt")).exists()

    # add (provide master password and account password via stdin prompts)
    # getpass reads from tty normally; we bypass by setting environment var PYTHONGETWARNINGS? Not needed.
    # Instead, pass --password to avoid interactive input for the account password, and simulate getpass for master.
    # We'll monkeypatch getpass by setting the environment variable that vault.py reads using getpass.getpass.
    # Since we can't monkeypatch across process easily, we test retrieval logic using known master by piping it twice.
    # The CLI prompts "Master password:" (no echo). We'll feed it via stdin.
    mpw = b"SecretMaster\n"
    r = run([PY, CLI, "--vault", str(vault), "add", "--name", "github", "--username", "alice", "--password", "PW123!"],
            input=mpw, stdout=PIPE, stderr=PIPE)
    assert r.returncode == 0, r.stderr.decode()

    # list
    r = cli("--vault", str(vault), "list")
    assert b"github" in r.stdout

    # get (masked)
    r = run([PY, CLI, "--vault", str(vault), "get", "--keyword", "git"], input=mpw, stdout=PIPE, stderr=PIPE)
    assert r.returncode == 0
    out = r.stdout.decode()
    assert "password=******" in out

    # get (reveal)
    r = run([PY, CLI, "--vault", str(vault), "get", "--keyword", "git", "--reveal"], input=mpw, stdout=PIPE, stderr=PIPE)
    assert r.returncode == 0
    out = r.stdout.decode()
    assert "password=PW123!" in out

    # delete
    r = cli("--vault", str(vault), "delete", "--name", "github")
    assert r.returncode == 0
    r = cli("--vault", str(vault), "list")
    assert b"(empty)" in r.stdout

def test_duplicate_entry_fails(tmp_path: Path):
    vault = tmp_path / "dup.json"
    r = cli("--vault", str(vault), "init")
    assert r.returncode == 0

    mpw = b"SecretMaster\n"
    r = run([PY, CLI, "--vault", str(vault), "add", "--name", "x", "--username", "u", "--password", "p"],
            input=mpw, stdout=PIPE, stderr=PIPE)
    assert r.returncode == 0

    r = run([PY, CLI, "--vault", str(vault), "add", "--name", "x", "--username", "u2", "--password", "p2"],
            input=mpw, stdout=PIPE, stderr=PIPE)
    assert r.returncode != 0
    assert b"already exists" in r.stderr or b"already exists" in r.stdout
