import json
import csv

def save_students_json(file_path, students):
    with open(file_path, 'w') as f:
        json.dump([s.__dict__ for s in students], f, indent=4)

def load_students_json(file_path):
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
            from student import Student
            return [Student(**s) for s in data]
    except FileNotFoundError:
        return []

def save_students_csv(file_path, students):
    with open(file_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['name', 'age', 'class_level', 'subjects', 'grades'])
        for s in students:
            writer.writerow([s.name, s.age, s.class_level, '|'.join(s.subjects), '|'.join(map(str, s.grades))])

def load_students_csv(file_path):
    try:
        with open(file_path, 'r') as f:
            reader = csv.DictReader(f)
            from student import Student
            return [Student(row['name'], int(row['age']), row['class_level'], row['subjects'].split('|'), list(map(float, row['grades'].split('|')))) for row in reader]
    except FileNotFoundError:
        return []
