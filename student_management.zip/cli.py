from student import Student
from storage import save_students_json, load_students_json, save_students_csv, load_students_csv

students = []

def add_student():
    name = input("Name: ")
    age = int(input("Age: "))
    class_level = input("Class Level: ")
    subjects = input("Subjects (comma-separated): ").split(',')
    grades = list(map(float, input("Grades (comma-separated): ").split(',')))
    students.append(Student(name, age, class_level, subjects, grades))
    print("Student added!")

def view_students():
    for s in students:
        print(s)

def save_data():
    fmt = input("Save format (json/csv): ").lower()
    file_path = input("File path: ")
    if fmt == "json":
        save_students_json(file_path, students)
    elif fmt == "csv":
        save_students_csv(file_path, students)
    print("Data saved!")

def load_data():
    fmt = input("Load format (json/csv): ").lower()
    file_path = input("File path: ")
    global students
    if fmt == "json":
        students = load_students_json(file_path)
    elif fmt == "csv":
        students = load_students_csv(file_path)
    print("Data loaded!")

def main_menu():
    while True:
        print("\n--- Student Management ---")
        print("1. Add Student")
        print("2. View Students")
        print("3. Save Data")
        print("4. Load Data")
        print("5. Exit")
        choice = input("Choose an option: ")
        if choice == "1":
            add_student()
        elif choice == "2":
            view_students()
        elif choice == "3":
            save_data()
        elif choice == "4":
            load_data()
        elif choice == "5":
            break
