import unittest
from student import Student

class TestStudent(unittest.TestCase):
    def test_average(self):
        s = Student("Dennis", 14, "Grade 9", ["Math", "CS"], [90, 100])
        self.assertEqual(s.calculate_average(), 95)

if __name__ == "__main__":
    unittest.main()
