class Student:
    def __init__(self, name, age, class_level, subjects, grades):
        self.name = name
        self.age = age
        self.class_level = class_level
        self.subjects = subjects
        self.grades = grades

    def calculate_average(self):
        return sum(self.grades) / len(self.grades) if self.grades else 0

    def __str__(self):
        return f"{self.name} ({self.class_level}) - Avg: {self.calculate_average():.2f}"
